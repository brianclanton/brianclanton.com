﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

/*
 * Brian Clanton
 * Joe Trotta
 * Elvis Perez
 * 
 * 10/5/11
 */
namespace AnimationTest
{
    public class Node<T>
    {
        public T Element { get; set; }
        public Node<T> Next { get; set; }

        public Node(T element)
        {
            this.Element = element;
        }

        public bool Equals(Node<T> node)
        {
            return this.Element.Equals(node.Element);
        }

        override public string ToString()
        {
            return "" + Element + "," + Next;
        }

    }
}
