﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AnimationTest
{
    public class Queue<T>
    {
        private Node<T> head;

        public Queue() { }

        public T peek()
        {
            return head == null ? default(T) : head.Element;
        }

        public void enqueue(T element)
        {
            Node<T> toAdd = new Node<T>(element);

            if (head == null)
                head = toAdd;
            else
            {
                Node<T> temp;

                for (temp = head; temp.Next != null; temp = temp.Next) ;

                temp.Next = toAdd;
            }
        }

        public T dequeue()
        {
            T value = peek();

            if (head != null)
                head = head.Next;
            
            return value;
        }

        public bool isEmpty()
        {
            return head == null;
        }

        public override string ToString()
        {
            return isEmpty() ? "Empty" : head.ToString();
        }

        public int Size
        {
            get
            {
                int s = 0;

                for (Node<T> temp = head; temp != null; temp = temp.Next)
                    s++;

                return s;
            }
        }
    }
}
