﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;

namespace AnimationTest
{
    /// <summary>
    /// Stores a queue of actions to be played in a specified sequence.
    /// </summary>
    public class Animation : ICloneable
    {
        public string Name;
        public Action[] ActionList;
        public Queue<Action> ActionQueue;

        public Animation()
        {
            ActionQueue = new Queue<Action>();
        }

        /// <summary>
        /// Initializes queue from list.
        /// </summary>
        public void InitQueue()
        {
            foreach (Action a in ActionList)
                ActionQueue.enqueue(a);

            ActionList = null;
        }

        public bool HasNext()
        {
            return !ActionQueue.isEmpty();
        }

        public Action Next()
        {
            return ActionQueue.dequeue();
        }

        public object Clone()
        {
            Animation a = new Animation();
            a.Name = Name;
            a.ActionList = ActionList;
            a.InitQueue();

            return a;
        }
    }
}
