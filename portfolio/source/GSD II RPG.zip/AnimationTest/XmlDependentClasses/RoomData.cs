﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AnimationTest
{
    /// <summary>
    /// Stores data from Xml to be interpreted by a Room object.
    /// </summary>
    public class RoomData
    {
        public string BG;
        public string Condition;
        public string[] Enemies;
    }

}
