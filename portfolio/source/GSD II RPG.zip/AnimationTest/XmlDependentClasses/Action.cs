﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AnimationTest
{
    /// <summary>
    /// Stores information for an action to be performed by a sprite.
    /// </summary>
    public class Action
    {
        public string Name;
        public double Duration;

        public Action() { }

        public Action(string name)
        {
            Name = name;
        }

        public Action(string name, float duration)
        {
            Name = name;
            Duration = duration;
        }

        public override string ToString()
        {
            return Name;
        }
    }
}
