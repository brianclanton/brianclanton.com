﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AnimationTest
{
    public class UnitData
    {
        public string Type;

        public int MaxHp;
        public int Atk, Def;
        public double Crit;
        public double WaitTime;
    }
}
