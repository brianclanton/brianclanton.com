﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

/*
 * Brian Clanton
 * 9/27/11
 */
namespace AnimationTest
{
    /// <summary>
    /// A UnitGroup specific to storing information on enemy hordes.
    /// </summary>
    public class Horde : UnitGroup
    {
        private const double RARE_DROP_RATE = .2;

        private Item normalDropItem;
        private Item rareDropItem;

        public Horde() : base() { }

        public Horde(Item normalDropItem) : base()
        {
            this.normalDropItem = normalDropItem;
        }

        public Horde(Item normalDropItem, Item rareDropItem) : base()
        {
            this.normalDropItem = normalDropItem;
            this.rareDropItem = rareDropItem;
        }

        /// <summary>
        /// Returns either a normal or rare drop item after defeat.
        /// </summary>
        /// <param name="condition"></param>
        /// <returns></returns>
        public Item getDropItem(BattleCondition condition)
        {
            Random r = new Random();

            if (rareDropItem != null && (condition == BattleCondition.Lucky || (condition != BattleCondition.Lucky && r.NextDouble() <= RARE_DROP_RATE)))
                return rareDropItem;
            else if (normalDropItem != null)
                return normalDropItem;
            else
                return null;
        }

        public static Horde operator +(Horde h, Unit u)
        {
            h.AddMember(u);
            return h;
        }
    }
}
