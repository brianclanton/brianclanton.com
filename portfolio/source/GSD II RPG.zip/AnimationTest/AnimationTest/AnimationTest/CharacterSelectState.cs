﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace AnimationTest
{
    /// <summary>
    /// This game state handles initial party character selection.
    /// </summary>
    class CharacterSelectState : GameState
    {
        private static UnitType[] characterClasses = { UnitType.Soldier, UnitType.Armored_Soldier, UnitType.Swordsmaster };

        private Menu[] classMenus;
        private Menu currentMenu;
        private Menu CurrentMenu
        {
            get { return currentMenu; }
            set
            {
                if (currentMenu != null)
                    currentMenu.Focused = false;

                currentMenu = value;
                currentMenu.Focused = true;
            }
        }

        private Sprite[] classIcons;

        private int currentIndex = 0;

        private bool pressed = false;

        public CharacterSelectState()
        {
            Initialize();
        }

        protected override void Initialize()
        {
            classMenus = new Menu[3];
            classIcons = new Sprite[3];

            string[] classNames = new string[characterClasses.Length];
            for (int i = 0; i < characterClasses.Length; i++)
                classNames[i] = UnitFactory.FormatUnitType(characterClasses[i]);

            // Create menus and class icons
            for (int i = 0; i < classMenus.Length; i++)
            {
                classMenus[i] = new Menu(classNames,
                    new Vector2((i + 1) * MainGame.Width / (classMenus.Length + 1) - 150, (int)(MainGame.Height * .75)), 150, 125, false);
                classMenus[i].Focused = false;

                classIcons[i] = new Sprite(Assets.GetSprite(UnitType.Soldier));
                classIcons[i].Position = new Vector2((i + 1) * MainGame.Width / (classIcons.Length + 1), MainGame.Height / 2);
            }

            CurrentMenu = classMenus[currentIndex];
        }

        public override void Update(float dT)
        {
            #region Key Input
            if (Keyboard.GetState(PlayerIndex.One).IsKeyDown(Keys.Right))
            {
                if (!pressed)
                {
                    pressed = true;

                    currentIndex = (currentIndex + 1) % classMenus.Length;
                    CurrentMenu = classMenus[currentIndex];
                }
            }
            else if (Keyboard.GetState(PlayerIndex.One).IsKeyDown(Keys.Left))
            {
                if (!pressed)
                {
                    pressed = true;

                    currentIndex--;

                    if (currentIndex < 0)
                        currentIndex = classMenus.Length - 1;

                    CurrentMenu = classMenus[currentIndex];
                }
            }
            else if (Keyboard.GetState(PlayerIndex.One).IsKeyDown(Keys.Enter))
            {
                if (!pressed)
                {
                    Party party = new Party();

                    foreach (Menu m in classMenus)
                        party.AddMember(UnitFactory.CreateUnit(characterClasses[m.SelectedIndex]));

                    for (int i = 0; i < party.Size; i++)
                    {
                        Sprite temp = party[i].UnitSprite;
                        temp.Position = new Vector2(100, (i + 1) * (MainGame.Height / (party.Size + 1)));
                    }

                    MainGame.StartGame(party);
                }
            }
            else
                pressed = false;
            #endregion

            // Updates texture based on current menu selection
            for (int i = 0; i < classMenus.Length; i++)
            {
                classMenus[i].Update(dT);
                classIcons[i].tex = Assets.GetSprite(classMenus[i].SelectedText);
            }

            foreach (Sprite s in classIcons)
                s.Update(dT);
        }

        public override void Draw(SpriteBatch spriteBatch)
        {
            foreach (Sprite s in classIcons)
                s.Draw(spriteBatch);

            foreach (Menu m in classMenus)
                m.Draw(spriteBatch);
        }
    }
}
