﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Threading;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace AnimationTest
{

    public class Sprite : IScreenDrawable
    {
        public enum AnimationState { NONE, JUMP, SPIN_JUMP, SHAKE, STEP_FORWARD };

        private static Animation[] animationMap;

        private Vector2 position;
        public Vector2 Position
        {
            get { return position; }
            set
            {
                position = value;
                animPosition = position;
            }
        }

        public int Width
        {
            get { return tex.Width; }
        }

        public int Height
        {
            get { return tex.Height; }
        }
            
        private Vector2 animPosition, velocity;
        private Vector2 origin;
        private float rotationAngle = 0f, dTheta;
        private int delay;

        private AnimationState currentAction = AnimationState.NONE;
        private Queue<Action> currentActionQueue;

        public Texture2D tex;

        private const float GRAVITY = 500f;

        private Random rand;

        public Sprite(Texture2D tex)
        {
            velocity = Vector2.Zero;

            this.tex = tex;
            origin = new Vector2(tex.Width / 2, tex.Height / 2);
            rand = new Random();

            currentActionQueue = new Queue<Action>();
        }

        public AnimationState CurrentAction
        {
            get { return currentAction; }
        }

        /// <summary>
        /// Initializes map of animation names to animation queues.
        /// </summary>
        /// <param name="list"></param>
        public static void InitAnimationMap(Animation[] list)
        {
            animationMap = list;
        }

        /// <summary>
        /// Checks if sprite is currently animated.
        /// </summary>
        /// <returns></returns>
        public bool IsAnimated()
        {
            return currentAction != AnimationState.NONE;
        }

        /// <summary>
        /// Plays an action from an animation queue.
        /// </summary>
        /// <param name="a"></param>
        /// <param name="dT"></param>
        private void PlayAction(Action a, float dT)
        {
            switch (a.Name)
            {
                case "jump":
                    Jump((float) a.Duration);
                    break;

                case "spin_jump":
                    SpinJump((float) a.Duration, dT);
                    break;

                case "shake":
                    Shake();
                    break;

                case "step_forward":
                    StepForward();
                    break;
            }
        }

        /// <summary>
        /// Stops an action.
        /// </summary>
        /// <param name="dT"></param>
        private void EndAnimation(float dT)
        {
            if (currentActionQueue.isEmpty())
                currentAction = AnimationState.NONE;
            else
                PlayAction(currentActionQueue.dequeue(), dT);
        }

        public void Update(float dT) 
        {
            // Starts animation
            if (currentAction == AnimationState.NONE && !currentActionQueue.isEmpty())
                PlayAction(currentActionQueue.dequeue(), dT);

            if (currentAction != AnimationState.NONE)
            {
                // Apply gravity for jumping animations
                if (currentAction == AnimationState.JUMP || currentAction == AnimationState.SPIN_JUMP)
                    velocity.Y += GRAVITY * dT;

                // Update position
                animPosition.X += velocity.X * dT;
                animPosition.Y += velocity.Y * dT;

                if (currentAction == AnimationState.SPIN_JUMP)
                {
                    // Update rotation angle for spin jump
                    rotationAngle += dTheta;
                    rotationAngle = Math.Sign(dTheta) == 1 ? Math.Min(MathHelper.TwoPi, rotationAngle) :
                        Math.Max(-MathHelper.TwoPi, rotationAngle);
                }
                else if (currentAction == AnimationState.SHAKE)
                {
                    // Update shake animation
                    if (Math.Abs(position.X - animPosition.X) >= 15)
                        velocity = new Vector2(50 * (position.X > MainGame.Width / 2 ? -1 : 1), 0);
                    else if (position.X < MainGame.Width / 2 && Math.Sign(velocity.X) == 1 && animPosition.X >= position.X ||
                        position.X > MainGame.Width / 2 && Math.Sign(velocity.X) == -1 && animPosition.X <= position.X)
                    {
                        velocity = Vector2.Zero;
                        animPosition = position;
                        EndAnimation(dT);
                    }
                }
                else if (currentAction == AnimationState.STEP_FORWARD)
                {
                    // Update step forward animation
                    if (Math.Abs(animPosition.X - position.X) >= 15)
                    {
                        velocity = Vector2.Zero;
                        Thread t = new Thread(Wait);
                        t.Start();
                    }
                    else if (position.X < MainGame.Width / 2 && Math.Sign(velocity.X) == -1 && animPosition.X <= position.X ||
                        position.X > MainGame.Width / 2 && Math.Sign(velocity.X) == 1 && animPosition.X >= position.X)
                    {
                        velocity = Vector2.Zero;
                        animPosition = position;
                        EndAnimation(dT);
                    }
                }
                if ((currentAction == AnimationState.JUMP || currentAction == AnimationState.SPIN_JUMP) &&
                    animPosition.Y >= position.Y)
                {
                    rotationAngle = 0;
                    animPosition.Y = position.Y;
                    velocity = Vector2.Zero;
                    EndAnimation(dT);
                }
            }
        }

        /// <summary>
        /// Trigger an animation queue to play.
        /// </summary>
        /// <param name="animation"></param>
        public void Play(string animation)
        {
            if (currentAction == AnimationState.NONE)
            {
                foreach (Animation a in animationMap)
                    if (a.Name == animation)
                    {
                        currentActionQueue = (a.Clone() as Animation).ActionQueue;
                        break;
                    }
            }
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(tex, animPosition, null, Color.White, rotationAngle, origin, 1.0f, SpriteEffects.None, 0f);
        }

        public void Jump(float seconds) 
        {
            currentAction = AnimationState.JUMP;
            velocity = new Vector2(0, -.5f * GRAVITY * seconds);
        }

        public void SpinJump(float seconds, double dT)
        {
            currentAction = AnimationState.SPIN_JUMP;
            velocity = new Vector2(0, -.5f * GRAVITY * seconds);
            dTheta = (rand.Next(2) == 0 ? 1 : -1) * MathHelper.TwoPi * (float)dT / (seconds);
        }

        public void Shake()
        {
            currentAction = AnimationState.SHAKE;
            velocity = new Vector2(-175 * (position.X > MainGame.Width / 2 ? -1 : 1), 0);
        }

        public void StepForward()
        {
            currentAction = AnimationState.STEP_FORWARD;
            velocity = new Vector2(50 * (position.X > MainGame.Width / 2 ? -1 : 1), 0);
            delay = 1000;
        }

        private void Wait()
        {
            Thread.Sleep(delay);

            if (currentAction == AnimationState.STEP_FORWARD)
                velocity = new Vector2(-50 * (position.X > MainGame.Width / 2 ? -1 : 1), 0);
        }
    }
}

