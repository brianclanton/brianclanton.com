﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AnimationTest
{
    class Stack<T>
    {
        private Node<T> head;

        public Stack() { }

        public T pop()
        {
            if (head == null)
                return default(T);
            else
            {
                Node<T> temp;

                for (temp = head; temp.Next != null; temp = temp.Next) ;

                T value = temp.Element;
                temp = null;

                return value;
            }
        }

        public void push(T element)
        {
            Node<T> toAdd = new Node<T>(element);

            if (head == null)
                head = toAdd;

            else
            {
                Node<T> temp;

                for (temp = head; temp.Next != null; temp = temp.Next) ;

                temp.Next = toAdd;
            }
        }

        public bool isEmpty()
        {
            return head == null;
        }

    }
}
