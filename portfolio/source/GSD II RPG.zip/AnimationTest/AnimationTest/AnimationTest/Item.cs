﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

/*
 * Brian Clanton
 * 9/27/11
 */
namespace AnimationTest
{
    public interface Item
    {
        void activate(Unit a);
    }

    /// <summary>
    /// Heals a unit by 10 hp.
    /// </summary>
    public class Potion : Item
    {
        private int healingFactor;

        public Potion()
        {
            healingFactor = 10;
        }

        public void activate(Unit a)
        {
            a.Hp = Math.Min(a.MaxHp, a.Hp + healingFactor);
        }

        public override string ToString()
        {
            return "Potion";
        }
    }

    /// <summary>
    /// Heals a unit to full hp.
    /// </summary>
    public class MaxPotion : Item
    {
        public void activate(Unit a)
        {
            a.Hp = a.MaxHp;
        }

        override public string ToString()
        {
            return "Max Potion";
        }
    }

    /// <summary>
    /// Revives a dead unit to 1/4 of max hp.
    /// </summary>
    public class Revive : Item
    {
        public void activate(Unit a)
        {
            if (a.IsDead())
            {
                a.Revive();
                a.Hp = a.MaxHp / 4;
            }
        }

        public override string ToString()
        {
            return "Revive";
        }
    }
}
