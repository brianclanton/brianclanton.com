﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace AnimationTest
{
    /// <summary>
    /// This game state handles party versus horde battle.
    /// </summary>
    public class BattleGameState : GameState
    {
        #region Declarations
        private Party party;
        private Horde horde;

        private object hordeLock = new object();

        private BattleCondition condition;

        private Texture2D background;

        private Menu[] partyMenus;
        private Menu currentPartyMenu;

        private Thread hordeAttack;

        private Sprite[] roomDisplay;

        private int partyIndex, hordeIndex;
        private bool selectingParty = true;
        private bool pressed = false, selectionMade = false, selectionInterpreted = false;
        private bool battleEnded = false;

        private float animDistance;
        private bool movingRight = true;
        #endregion

        public BattleGameState(Party party, Horde horde, BattleCondition condition)
        {
            this.party = party;
            this.horde = horde;
            this.condition = condition;

            Initialize();
        }

        public BattleGameState(Party party, Room room) : this(party, room.GetHorde(), room.GetCondition()) 
        {
            background = Assets.GetBackground(room.GetBackground());
        }

        /// <summary>
        /// Resets cursor bouncing animation
        /// </summary>
        private void ResetAnimation()
        {
            animDistance = 0;
            movingRight = true;
        }

        #region GameState Implementation
        override protected void Initialize()
        {
            // Set party and horde sprite positions on the screen
            for (int i = 0; i < party.Size; i++)
                party[i].UnitSprite.Position = new Vector2(100, (i + 1) * (MainGame.Height / (party.Size + 1)));
            for (int i = 0; i < horde.Size; i++)
                horde[i].UnitSprite.Position = new Vector2(MainGame.Width - 100, (i + 1) * (MainGame.Height / (horde.Size + 1)));

            // Create a menu for each party member
            partyMenus = new Menu[party.Size];
            for (int i = 0; i < partyMenus.Length; i++)
                partyMenus[i] = new Menu(new string[] { party[i].GetType().Name == "Healer" ? "Heal" : "Attack", "Defend" },
                    party[i].UnitSprite.Position, party[i].UnitSprite.Width, party[i].UnitSprite.Height, true);

            // Create room display
            roomDisplay = new Sprite[MainGame.TotalRoomCount];
            for (int i = 0; i < roomDisplay.Length; i++) {
                if (i < MainGame.CurrentRoom)
                    roomDisplay[i] = new Sprite(Assets.GetIcon("Room (Traveled)"));
                else if (i == MainGame.CurrentRoom)
                    roomDisplay[i] = new Sprite(Assets.GetIcon("Room (Current)"));
                else
                    roomDisplay[i] = new Sprite(Assets.GetIcon("Room (Untraveled)"));

                roomDisplay[i].Position = new Vector2(MainGame.Width - (roomDisplay.Length - i) * 48, 20);
            }

            hordeAttack = new Thread(delegate()
            {
                while (true)
                {
                    if (!horde.AllCannotAttack())
                    {
                        lock (hordeLock)
                        {
                            Random r = new Random();

                            for (int i = 0; i < horde.Size; i++)
                                if (horde[i].CanAttack)
                                {
                                    int index;

                                    do
                                    {
                                        index = r.Next(party.Size);
                                    } while (party[index].IsDead());

                                    horde[i].Attack(party[index]);
                                    break;
                                }
                        }
                    }

                    Thread.Sleep(100);
                } 
            });
            hordeAttack.Start();
        }

        override public void Update(float dT)
        {
            // Check if battle is over
            if (horde.AllDead() || party.AllDead())
            {
                battleEnded = true;
                hordeAttack.Abort();
            }

            #region Cursor Adjustment
            // Adjust party index
            if (selectingParty && !party[partyIndex].CanAttack)
            {
                for (int i = 0; i < party.Size; i++)
                    if (!party[i].IsDead() && party[i].CanAttack)
                    {
                        partyIndex = i;
                        break;
                    }
            }
            // Adjust horde index
            else if (!selectingParty && horde[hordeIndex].IsDead())
            {
                for (int i = 0; i < horde.Size; i++)
                    if (!horde[i].IsDead())
                    {
                        hordeIndex = i;
                        break;
                    }
            }
            // Update cursor boucning animation
            if (!battleEnded && (currentPartyMenu == null || !currentPartyMenu.Visible))
            {
                animDistance += .3f * (movingRight ? 1 : -1);

                if (animDistance <= 0)
                    movingRight = true;
                else if (animDistance >= 7)
                    movingRight = false;
            }
            #endregion

            #region Key Input
            if (currentPartyMenu == null || !currentPartyMenu.Visible || selectionInterpreted)
            {
                if (Keyboard.GetState(PlayerIndex.One).IsKeyDown(Keys.Up))
                {
                    if (!pressed)
                        if (selectingParty)
                            partyIndex = UpdateArrowLocation(Keys.Up, partyIndex, party);
                        else
                            hordeIndex = UpdateArrowLocation(Keys.Up, hordeIndex, horde);

                    ResetAnimation();
                    pressed = true;
                }
                else if (Keyboard.GetState(PlayerIndex.One).IsKeyDown(Keys.Down))
                {
                    if (!pressed)
                        if (selectingParty)
                            partyIndex = UpdateArrowLocation(Keys.Down, partyIndex, party);
                        else
                            hordeIndex = UpdateArrowLocation(Keys.Down, hordeIndex, horde);

                    ResetAnimation();
                    pressed = true;
                }
                else if (!party.AllCannotAttack() && Keyboard.GetState(PlayerIndex.One).IsKeyDown(Keys.X))
                {
                    if (!pressed)
                        selectionMade = true;

                    ResetAnimation();
                    pressed = true;
                }
                else if (!selectingParty && Keyboard.GetState(PlayerIndex.One).IsKeyDown(Keys.Z))
                {
                    if (!pressed)
                    {
                        currentPartyMenu.SelectionMade = false;
                        selectingParty = true;
                    }

                    ResetAnimation();
                    pressed = true;
                }
                else if (battleEnded && Keyboard.GetState(PlayerIndex.One).IsKeyDown(Keys.Enter))
                {
                    if (!pressed)
                    {
                        if (party.AllDead())
                            GoToGameOverState();
                        else if (horde.AllDead())
                            GoToVictoryState();
                    }
                }
                else
                {
                    if (selectionMade)
                    {
                        selectionMade = false;

                        if (selectingParty)
                        {
                            currentPartyMenu = partyMenus[partyIndex];
                            currentPartyMenu.Visible = true;
                        }
                        else
                        {
                            party[partyIndex].Attack(horde[hordeIndex]);
                            selectingParty = true;
                            currentPartyMenu.Visible = false;
                            currentPartyMenu.SelectionMade = false;
                        }
                    }

                    pressed = false;
                }
            }
            #endregion

            #region Menu Interpretation
            if (currentPartyMenu != null && currentPartyMenu.Visible && selectingParty) {
                if (currentPartyMenu.SelectionMade)
                {
                    // Interpret menu selection
                    switch (currentPartyMenu.SelectedIndex)
                    {
                        case 0:
                            selectingParty = false;
                            selectionMade = false;
                            break;

                        case 1:
                            selectionMade = false;
                            currentPartyMenu.Visible = false;
                            currentPartyMenu.SelectionMade = false;
                            party[partyIndex].Defend();
                            break;
                    }

                    selectionInterpreted = true;
                }
 
                if (selectingParty)
                    currentPartyMenu.Update(dT);
            }
            #endregion

            if (!battleEnded)
            {
                party.Update(dT);
                horde.Update(dT);
            }
        }

        override public void Draw(SpriteBatch spriteBatch)
        {
            // Draw Background
            spriteBatch.Draw(background, Vector2.Zero, Color.White);

            if (!battleEnded && currentPartyMenu != null && currentPartyMenu.Visible)
                currentPartyMenu.Draw(spriteBatch);

            party.Draw(spriteBatch);
            horde.Draw(spriteBatch);

            Unit selectedUnit;

            // Draw cursor
            if (!battleEnded)
            {
                if (selectingParty && (currentPartyMenu == null || !currentPartyMenu.Visible))
                {
                    selectedUnit = party[partyIndex];

                    if (selectedUnit.CanAttack && !selectedUnit.IsDead())
                        spriteBatch.Draw(Assets.GetIcon("Left Arrow"),
                            new Vector2(selectedUnit.UnitSprite.Position.X + selectedUnit.UnitSprite.Width / 2 + 20 + animDistance,
                                selectedUnit.UnitSprite.Position.Y - 4), Color.White);
                }
                else if (!selectingParty)
                {
                    selectedUnit = horde[hordeIndex];

                    if (!selectedUnit.IsDead())
                        spriteBatch.Draw(Assets.GetIcon("Right Arrow"),
                               new Vector2(selectedUnit.UnitSprite.Position.X - (selectedUnit.UnitSprite.Width / 2 + 20 + animDistance),
                                   selectedUnit.UnitSprite.Position.Y - 4), Color.White);
                }
            }
            else
            {
                spriteBatch.DrawString(Assets.trebuchet, "Press Enter to Continue", new Vector2(MainGame.Width / 2, MainGame.Height / 2), Color.White);
            }

            spriteBatch.DrawString(Assets.trebuchet, "Condition: " + condition, new Vector2(16, 16), Color.White);

            foreach (Sprite s in roomDisplay)
                s.Draw(spriteBatch);
        }
        #endregion

        /// <summary>
        /// Updates cursor location based on key input
        /// </summary>
        /// <param name="k"></param>
        /// <param name="startIndex"></param>
        /// <param name="ug"></param>
        /// <returns></returns>
        private int UpdateArrowLocation(Keys k, int startIndex, UnitGroup ug)
        {
            int index = startIndex;
           
            do
            {
                if (k == Keys.Up)
                {
                    index--;
                    if (index < 0)
                        index = ug.Size - 1;
                } 
                else if (k == Keys.Down)
                    index = (index + 1) % ug.Size;
            } while (index != startIndex && ug[index].IsDead() && (ug is Party ? !ug[index].CanAttack : true));

            return index;
        }

        private void GoToVictoryState()
        {
            Console.WriteLine("Battle ended");
            MainGame.GoToNextRoom();
        }

        private void GoToGameOverState()
        {
            GoToVictoryState();
        }
    }
}
