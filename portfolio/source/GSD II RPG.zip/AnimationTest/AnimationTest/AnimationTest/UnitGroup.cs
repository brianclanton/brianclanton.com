﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

/*
 * Brian Clanton
 * 9/27/11
 */
namespace AnimationTest
{
    
    /// <summary>
    /// Stores a list of units and provides methods for easy access to these units.
    /// </summary>
    public abstract class UnitGroup : IScreenDrawable, IEnumerable
    {
        protected List<Unit> group;

        public UnitGroup()
        {
            group = new List<Unit>();
        }

        public int Size { get { return group.Count; } }

        public Unit this[int index]
        {
            get { return group[index]; }
            set { group[index] = value; }
        }

        public IEnumerator GetEnumerator()
        {
            return (group as IEnumerable).GetEnumerator();
        }

        public void AddMember(Unit a)
        {
            group.Add(a);
        }

        public bool AllDead()
        {
            for (int i = 0; i < group.Count; i++)
                if (!group[i].IsDead())
                    return false;
            return true;
        }

        public bool AllCannotAttack()
        {
            for (int i = 0; i < group.Count; i++)
                if (group[i].CanAttack && !group[i].IsDead())
                    return false;
            return true;
        }

        public void Update(float dT)
        {
            foreach (Unit u in group)
                u.Update(dT);
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            foreach (Unit u in group)
                u.Draw(spriteBatch);
        }

        /// <summary>
        /// Prints all group members.
        /// </summary>
        public void Print()
        {
            for (int i = 0; i < group.Count; i++)
                Console.WriteLine((i + 1) + ". " + group[i]);
        }

        /// <summary>
        /// Prints members of the UnitGroup that are not dead.
        /// </summary>
        public virtual void PrintLiveMembers()
        {
            for (int i = 0; i < group.Count; i++)
                if (!group[i].IsDead())
                    Console.WriteLine((i + 1) + ". " + group[i]);
        }
    }
}
