﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

/*
 * Brian Clanton
 * 9/27/11
 */
namespace AnimationTest
{
    /// <summary>
    /// Specific UnitGroup that stores information for the playable characters.
    /// </summary>
    public class Party : UnitGroup
    {
        private Inventory inventory;
        public Inventory Items { get { return inventory; } }

        public Party() : base()
        {
            inventory = new Inventory();
            inventory.AddItem(new Potion());
        }

        /// <summary>
        /// Adds and item to the inventory.
        /// </summary>
        /// <param name="i"></param>
        public void ObtainItem(Item i)
        {
            inventory.AddItem(i);
        }

        /// <summary>
        /// Uses and item from the inventory on the specified player.
        /// </summary>
        /// <param name="itemIndex"></param>
        /// <param name="playerIndex"></param>
        public void UseItem(int itemIndex, int playerIndex)
        {
            Item i = inventory.removeItem(itemIndex);
            i.activate(group[playerIndex]);
        }

        /// <summary>
        /// Resets moved boolean for all members and removes defending status.
        /// </summary>
        public void ResetTurn()
        {
            for (int i = 0; i < group.Count; i++)
            {
                group[i].CanAttack = false;
                group[i].LowerDefense();
            }
        }

        /// <summary>
        /// Prints members that are not dead and have not moved.
        /// </summary>
        public override void PrintLiveMembers()
        {
            for (int i = 0; i < group.Count; i++)
                if (!(group[i].IsDead() || group[i].CanAttack))
                    Console.WriteLine((i + 1) + ". " + group[i]);
        }

    }
}
