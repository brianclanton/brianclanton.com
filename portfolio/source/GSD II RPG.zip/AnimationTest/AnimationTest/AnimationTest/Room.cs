﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

/*
 * Brian Clanton
 * 9/27/11
 */
namespace AnimationTest
{
    public enum BattleCondition { Normal, Foggy, Lucky };

    /// <summary>
    /// Stores information for a room, including the enemy horde and battle condition.
    /// </summary>
    public class Room
    {
        private Horde horde;
        private BattleCondition condition;
        private string background;

        public Room() { }

        public Room(Horde horde, BattleCondition condition)
        {
            this.horde = horde;
            this.condition = condition;
        }

        public Room(RoomData data)
        {
            switch (data.Condition)
            {
                case "Fog":
                    condition = BattleCondition.Foggy;
                    break;

                case "Lucky":
                    condition = BattleCondition.Lucky;
                    break;

                default:
                    condition = BattleCondition.Normal;
                    break;
            }

            horde = new Horde();

            // Adds enemies to horde
            foreach (string s in data.Enemies)
                foreach (UnitType ut in Enum.GetValues(typeof(UnitType)))
                    if (UnitFactory.FormatUnitType(ut) == s)
                        horde.AddMember(UnitFactory.CreateUnit(ut));

            background = data.BG;
        }

        public Horde GetHorde()
        {
            return horde;
        }

        public BattleCondition GetCondition()
        {
            return condition;
        }

        public string GetBackground()
        {
            return background;
        }
    }
}
