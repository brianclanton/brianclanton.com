﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AnimationTest
{
    abstract class Weapon
    {
        private string name;
        private int atkBonus;
        private int critBonus;

        // To be implemented
    }
}
