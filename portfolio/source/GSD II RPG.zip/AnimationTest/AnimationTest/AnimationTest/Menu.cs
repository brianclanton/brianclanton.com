﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace AnimationTest
{
    public class Menu : IScreenDrawable
    {
        private string[] menuItems;
        private Vector2[] menuItemPositions;

        private int selectedIndex = 0;
        public int SelectedIndex
        {
            get { return selectedIndex; }
        }

        public string SelectedText
        {
            get { return menuItems[selectedIndex]; }
        }

        private int width, height;

        private float animDistance;
        private bool movingRight = true;

        public bool Visible = false;
        public bool SelectionMade = false;
        public bool Selectable = true;
        private bool focused = true;
        public bool Focused
        {
            get { return focused; }
            set
            {
                focused = value;

                if (!focused)
                    ResetAnimation();
            }
        }

        private bool pressed = false;

        public Menu(string[] s, Vector2 position, int width, int height, bool selectable)
        {
            menuItems = s;
            menuItemPositions = new Vector2[menuItems.Length];

            for (int i = 0; i < menuItemPositions.Length; i++)
                menuItemPositions[i] = new Vector2(position.X + width / 2 + 20, position.Y - height / 2 + i * (height / 4));

            this.width = width;
            this.height = height;
            Selectable = selectable;
        }

        private void ResetAnimation()
        {
            animDistance = 0;
            movingRight = true;
        }

        public void Update(float dT)
        {
            if (Focused)
            {
                if (Keyboard.GetState(PlayerIndex.One).IsKeyDown(Keys.Down))
                {
                    if (!pressed)
                    {
                        selectedIndex = (selectedIndex + 1) % menuItems.Length;

                        ResetAnimation();
                    }

                    pressed = true;
                }
                else if (Keyboard.GetState(PlayerIndex.One).IsKeyDown(Keys.Up))
                {
                    if (!pressed)
                    {
                        selectedIndex -= 1;

                        if (selectedIndex == -1)
                            selectedIndex = menuItems.Length - 1;

                        ResetAnimation();
                    }

                    pressed = true;
                }
                else if (Selectable && Keyboard.GetState(PlayerIndex.One).IsKeyDown(Keys.X))
                {
                    if (!pressed)
                    {
                        SelectionMade = true;

                        ResetAnimation();
                    }

                    pressed = true;
                }
                else if (Selectable && Keyboard.GetState(PlayerIndex.One).IsKeyDown(Keys.Z))
                {
                    if (!pressed)
                    {
                        if (SelectionMade)
                            SelectionMade = false;
                        else
                            Visible = false;

                        ResetAnimation();
                    }

                    pressed = true;
                }
                else
                    pressed = false;


                if (!SelectionMade)
                {
                    animDistance += .3f * (movingRight ? 1 : -1);

                    if (animDistance <= 0)
                        movingRight = true;
                    else if (animDistance >= 7)
                        movingRight = false;
                }
            }
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            for (int i = 0; i < menuItems.Length; i++)
                spriteBatch.DrawString(Assets.trebuchet, menuItems[i], menuItemPositions[i], 
                    SelectionMade && i == selectedIndex ? Color.Blue : Color.White);

            spriteBatch.Draw(Assets.GetIcon("Left Arrow"), new Vector2(menuItemPositions[selectedIndex].X + width + animDistance,
                menuItemPositions[selectedIndex].Y - 4), SelectionMade ? Color.Blue : Color.White);
        }
    }
}
