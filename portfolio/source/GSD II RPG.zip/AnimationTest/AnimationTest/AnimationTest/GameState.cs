﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace AnimationTest
{
    /// <summary>
    /// Base class for game states, which are used to separate different aspects of gameplay, such as character selection and battle.
    /// </summary>
    public abstract class GameState : IScreenDrawable
    {
        protected bool active;

        /// <summary>
        /// Initializes game state.
        /// </summary>
        abstract protected void Initialize();
        /// <summary>
        /// Updates game state components.
        /// </summary>
        /// <param name="dT"></param>
        abstract public void Update(float dT);
        /// <summary>
        /// Renders visible elements of the game state to screen.
        /// </summary>
        /// <param name="spriteBatch"></param>
        abstract public void Draw(SpriteBatch spriteBatch);

        public virtual bool isActive()
        {
            return active;
        }

        public virtual void setActive(bool active)
        {
            this.active = active;
        }
    }
}
