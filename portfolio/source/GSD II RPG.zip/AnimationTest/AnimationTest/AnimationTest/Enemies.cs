﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

/*
 * Brian Clanton
 * 9/27/11
 */
namespace AnimationTest
{
    /**
    /// <summary>
    /// Standard enemy unit with well-rounded stats.
    /// </summary>
    class Goblin : Unit
    {
        public Goblin() : base("Goblin", 20, 10, 5, .1, 4.5) { }
    }

    /// <summary>
    /// Low atk and crit, but high hp and def.
    /// </summary>
    class DeathTurtle : Unit
    {
        public DeathTurtle() : base("Death Turtle", 50, 10, 10, .05, 7) { }
    }

    /// <summary>
    /// Low hp and def, but high atk and crit.
    /// </summary>
    class Rogue : Unit
    {
        public Rogue() : base("Rogue", 15, 12, 2, .3, 3) { }
    }

    /// <summary>
    /// High hp and extremely high crit, but low atk.
    /// </summary>
    class Boss : Unit
    {
        public Boss() : base("Boss", 75, 7, 5, .5, 4) { }
    }
    */
}
