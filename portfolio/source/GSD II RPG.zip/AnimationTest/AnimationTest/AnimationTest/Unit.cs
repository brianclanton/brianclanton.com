﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

/*
 * Brian Clanton
 * 9/27/11
 */
namespace AnimationTest
{
    /// <summary>
    /// This class represents a fighting unit. It stores stat values and allows for attacking 
    /// and defending.
    /// </summary>
    public class Unit : IScreenDrawable
    {
        protected UnitType type;
        protected string formattedType;

        public int Hp, MaxHp;
        protected int atk, def;
        protected double crit;
        protected double waitTime, currentTime;

        protected bool dead = false;
        protected bool canAttack = false;
        protected bool defending = false;
        protected bool attacking = false;

        protected Sprite sprite;

        protected Texture2D normalImage, midairImage;

        public Sprite UnitSprite
        {
            get { return sprite; }
        }

        public bool CanAttack
        {
            get { return canAttack; }
            set { canAttack = value; }
        }

        public int Defense
        {
            get { return def; }
        }

        public string Name
        {
            get { return formattedType; }
        }

        public Unit(int maxHp, int atk, int def, double crit, double waitTime)
        {
            this.MaxHp = maxHp;
            Hp = maxHp;
            this.atk = atk;
            this.def = def;
            this.crit = crit;
            this.waitTime = waitTime;
            currentTime = 0;
        }

        public Unit(UnitType ut, UnitData ud) : this(ud.MaxHp, ud.Atk, ud.Def, ud.Crit, ud.WaitTime) 
        {
            type = ut;
            formattedType = UnitFactory.FormatUnitType(ut);

            normalImage = Assets.GetSprite(formattedType);
            if (Assets.GetSprite(formattedType + " (Shadowless)") != default(Texture2D))
                midairImage = Assets.GetSprite(formattedType + " (Shadowless)");
            sprite = new Sprite(normalImage);
        }

        /// <summary>
        /// Handles damage calculation for an attack.
        /// </summary>
        /// <param name="b"></param>
        public virtual void Attack(Unit b)
        {
            attacking = true;
            canAttack = false;
            b.attacking = true;
            b.canAttack = false;

            Random r = new Random();

            bool isCrit = r.NextDouble() <= crit;
            double damage = atk;

            if (isCrit)
                damage *= 1.5;

            int prevHp = b.Hp;

            if (midairImage != default(Texture2D))
                sprite.tex = midairImage;

            sprite.Play(midairImage != default(Texture2D) ? "jump_attack" : "slow_attack");
            Thread t = new Thread(delegate()
            {
                // Wait for animation to start
                while (!sprite.IsAnimated()) ;
                // Wait for animation to end
                while (sprite.IsAnimated())
                    Thread.Sleep(50);

                if (midairImage != default(Texture2D))
                    sprite.tex = normalImage;

                b.Hp = Math.Max(0, b.Hp - ((Math.Max(0, (int)damage - (b.Defense))) / (b.IsDefending() ? 2 : 1)));

                b.UnitSprite.Shake();

                if (b.Hp == 0)
                    b.Die();

                currentTime = 0;
                attacking = false;
                b.attacking = false;
            });

            t.Start();
        }

        /// <summary>
        /// Sets status of unit to dead.
        /// </summary>
        public void Die()
        {
            dead = true;
            CanAttack = false;
            currentTime = 0;
        }
        
        /// <summary>
        /// Sets status of unit to alive and sets hp to 1.
        /// </summary>
        public void Revive()
        {
            dead = false;
            Hp = 1;
        }

        /// <summary>
        /// Resets party unit between battles.
        /// </summary>
        public void Reset()
        {
            currentTime = 0;
            Hp = Math.Min(MaxHp, Hp + MaxHp / 4);
        }

        public override string ToString()
        {
            return formattedType;
        }

        /// <summary>
        /// Returns true if the unit is dead.
        /// </summary>
        /// <returns></returns>
        public bool IsDead()
        {
            return dead;
        }

        /// <summary>
        /// Returns true if a unit is defending.
        /// </summary>
        /// <returns></returns>
        public bool IsDefending()
        {
            return defending;
        }

        /// <summary>
        /// Sets defending status to true.
        /// </summary>
        public void Defend()
        {
            defending = true;
            currentTime = 0;
            CanAttack = false;
        }

        /*
         * Sets defending status to false.
         */
        public void LowerDefense()
        {
            defending = false;
        }

        public void Update(float dT)
        {
            if (!dead && !canAttack && !attacking)
            {
                // Update wait time
                if (currentTime < waitTime)
                    currentTime = Math.Min(waitTime, currentTime + dT);
                else
                    CanAttack = true;
            }

            sprite.Update(dT);
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            if (!dead)
            {
                // Draw HP bar
                double hpPercentage = (double)Hp / (double)MaxHp, waitPercentage = currentTime / waitTime;
                spriteBatch.Draw(Assets.GetIcon("Bar"), new Rectangle((int)sprite.Position.X - sprite.Width / 2 - 25, (int)sprite.Position.Y + sprite.Height / 2 + 10,
                    (int)(hpPercentage * 100), 10), Color.Green);
                // Draw wait bar
                spriteBatch.Draw(Assets.GetIcon("Bar"), new Rectangle((int)sprite.Position.X - sprite.Width / 2 - 25, (int)sprite.Position.Y + sprite.Height / 2 + 20,
                    (int)(waitPercentage * 100), 10), Color.DarkCyan);
            }

            // Draw sprite
            sprite.Draw(spriteBatch);
        }

    }
}
