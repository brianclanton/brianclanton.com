﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AnimationTest
{
    public enum UnitType { Soldier, Armored_Soldier, Swordsmaster, Healer, Goblin, Rogue, Death_Turtle, Boss }

    /// <summary>
    /// Creates units by type based on base stats read in from Xml.
    /// </summary>
    public class UnitFactory
    {
        private static  Dictionary<UnitType, UnitData> unitMap;

        /// <summary>
        /// Initialize map of unit types to unit data.
        /// </summary>
        /// <param name="data"></param>
        public static void Initialize(UnitData[] data)
        {
            unitMap = new Dictionary<UnitType, UnitData>();

            foreach (UnitData ud in data)
                foreach (UnitType ut in Enum.GetValues(typeof(UnitType)))
                    if (FormatUnitType(ut) == ud.Type)
                        unitMap[ut] = ud;
        }

        /// <summary>
        /// Creates a unit given a type.
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        public static Unit CreateUnit(UnitType type)
        {
            return new Unit(type, unitMap[type]);
        }

        /// <summary>
        /// Formats unit type string.
        /// </summary>
        /// <param name="ut"></param>
        /// <returns></returns>
        public static string FormatUnitType(UnitType ut)
        {
            return ut.ToString().Replace("_", " ");
        }
    }
}
