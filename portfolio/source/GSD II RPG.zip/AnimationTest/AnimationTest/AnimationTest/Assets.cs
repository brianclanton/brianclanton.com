﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace AnimationTest
{
    /// <summary>
    /// Stores images and fonts for runtime access.
    /// </summary>
    public class Assets
    {
        // Fonts
        public static SpriteFont trebuchet;

        private static Dictionary<string, Texture2D> spriteMap = new Dictionary<string,Texture2D>();
        private static Dictionary<string, Texture2D> iconMap = new Dictionary<string,Texture2D>();
        private static Dictionary<string, Texture2D> backgroundMap = new Dictionary<string, Texture2D>();

        public static void Initialize(ContentManager Content)
        {
            //Load directory info, abort if none
            DirectoryInfo spriteDir = new DirectoryInfo(Content.RootDirectory + "/Sprites");
            if (!spriteDir.Exists)
                throw new AssetNotFoundException();

            //Load all files that matches the file filter
            FileInfo[] spriteFiles = spriteDir.GetFiles("*.*");
            Console.WriteLine(spriteFiles.Length);
            foreach (FileInfo file in spriteFiles)
            {
                string key = Path.GetFileNameWithoutExtension(file.Name);
                Console.WriteLine(key);
                spriteMap[key] = Content.Load<Texture2D>("Sprites/" + key);
            }

            DirectoryInfo iconDir = new DirectoryInfo(Content.RootDirectory + "/Icons");
            if (!iconDir.Exists)
                throw new AssetNotFoundException();

            FileInfo[] iconFiles = iconDir.GetFiles("*.*");
            Console.WriteLine(iconFiles.Length);
            foreach (FileInfo file in iconFiles)
            {
                string key = Path.GetFileNameWithoutExtension(file.Name);
                Console.WriteLine(key);
                iconMap[key] = Content.Load<Texture2D>("Icons/" + key);
            }

            DirectoryInfo backgroundDir = new DirectoryInfo(Content.RootDirectory + "/BGs");
            if (!backgroundDir.Exists)
                throw new AssetNotFoundException();

            FileInfo[] backgroundFiles = backgroundDir.GetFiles(".");
            Console.WriteLine(backgroundFiles.Length);
            foreach (FileInfo file in backgroundFiles)
            {
                string key = Path.GetFileNameWithoutExtension(file.Name);
                Console.WriteLine(key);
                backgroundMap[key] = Content.Load<Texture2D>("BGs/" + key);
            }

            Console.WriteLine();

            trebuchet = Content.Load<SpriteFont>("Fonts/MenuFont");
        }

        /// <summary>
        /// Returns a sprite by name.
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public static Texture2D GetSprite(string name) 
        {
            if (spriteMap.ContainsKey(name))
                return spriteMap[name];
            else
                return default(Texture2D);
        }

        public static Texture2D GetSprite(UnitType ut)
        {
            return GetSprite(UnitFactory.FormatUnitType(ut));
        }

        /// <summary>
        /// Returns an icon by name.
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public static Texture2D GetIcon(string name)
        {
            if (iconMap.ContainsKey(name))
                return iconMap[name];
            else
                return default(Texture2D);
        }

        /// <summary>
        /// Returns a background by name.
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public static Texture2D GetBackground(string name)
        {
            if (backgroundMap.ContainsKey(name))
                return backgroundMap[name];
            else
                return default(Texture2D);
        }
            
    }

    public class AssetNotFoundException : ApplicationException
    {
        public AssetNotFoundException() : base("An asset was not found") { }
    }
}
