﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

/*
 * Brian Clanton
 * 9/27/11
 */
namespace AnimationTest
{
    /// <summary>
    /// Stores a list of items and provides methods for adding and removing items.
    /// </summary>
    public sealed class Inventory
    {
        private List<Item> items;

        public int Size { get { return items.Count; } }

        public Inventory()
        {
            items = new List<Item>();
        }

        public void AddItem(Item i)
        {
            items.Add(i);
        }

        public Item getItem(int index)
        {
            return items[index];
        }

        public Item removeItem(int index)
        {
            Item i = items[index];
            items.Remove(items[index]);
            return i;
        }

        public void printItemList()
        {
            for (int i = 0; i < items.Count; i++)
            {
                Console.WriteLine((i + 1) + ". " + getItem(i).ToString());
            }
        }

    }
}
