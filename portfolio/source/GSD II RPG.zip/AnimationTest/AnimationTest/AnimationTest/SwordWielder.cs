﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

/*
 * Brian Clanton
 * 9/27/11
 */
namespace AnimationTest
{
    /// <summary>
    /// Defines methods specific to units that wield swords.
    /// </summary>
    interface SwordWielder
    {
        // To be implemented in later versions.
        void spinSword();
    }
}
