﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

/*
 * Brian Clanton
 * 9/27/11
 */
namespace AnimationTest
{
    class Healer : Unit
    {
        public Healer() : base(20, 10, 0, 0, 4) { }

        public new void Attack(Unit b)
        {
            int prevHp = b.Hp; 
            b.Hp = Math.Min(b.MaxHp, b.Hp + atk);

            Console.WriteLine(formattedType + " heals " + b.Name + " by " + (b.Hp - prevHp) + " hp.");
        }
    }
}
