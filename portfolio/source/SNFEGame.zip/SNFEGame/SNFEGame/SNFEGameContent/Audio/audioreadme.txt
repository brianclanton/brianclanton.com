run.wav:
	http://www.freesound.org/people/bevangoldswain/sounds/54779/
	"bevangoldswain"
	'footsteps running/walking on a hard surface like wood/laminate, or pavement'
	
whip.wav:
	http://www.freesound.org/people/snowflakes/sounds/72189/
	"snowflakes"
	'A single whip swoosh sound made by swinging a wooden stick in the air. Recorded with Zoom H2.'

music.mp3:
	http://www.newgrounds.com/audio/listen/420922
	"Tom Olive"
	'http://soundcloud.com/tom -olive'