﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SNFEGame.Util;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace SNFEGame.Visual
{
    /// <summary>
    /// This is the default class for dealing with sprites: the character and environment
    /// </summary>
    public abstract class Sprite
    {
        protected Dictionary<string, Texture2D[]> animationMap;
        protected string currentAnimation;
        protected int currentFrameIndex = 0;
        protected float frameDuration;
        protected float elapsedTime;
        protected bool flip;
        public Texture2D texture;

        protected int boundingWidth, boundingHeight;

        public Vector2 position;
        public Color color = Color.White;

        public bool DrawingBounds
        {
            get;
            set;
        }

        public Rectangle Bounds
        {
            get { return new Rectangle((int) position.X + (CurrentFrame.Width - boundingWidth) / 2, (int) position.Y + (CurrentFrame.Height - boundingHeight) / 2, boundingWidth, boundingHeight); }
        }

        public int Width
        {
            get { return CurrentFrame.Width; }
        }

        public int Height
        {
            get { return CurrentFrame.Height; }
        }

        protected Texture2D CurrentFrame
        {
            get { return animationMap[currentAnimation][currentFrameIndex]; }
            set { animationMap[currentAnimation][currentFrameIndex] = value; }
        }

        private float imageCounter; ///A counter for showing which 

        public Sprite(Texture2D tex)
        {
            animationMap = new Dictionary<string, Texture2D[]>();
            currentAnimation = "blah";
            animationMap[currentAnimation] = new Texture2D[1];
            
            animationMap[currentAnimation][currentFrameIndex] = tex;
            frameDuration = 0f;
            texture = tex;
            boundingWidth = tex.Width;
            boundingHeight = tex.Height;
        }

        public Sprite(Dictionary<string, Texture2D[]> animationMap, string currentAnimation, float frameDuration)
        {
            this.animationMap = animationMap;
            this.frameDuration = frameDuration;
            this.currentAnimation = currentAnimation;

            boundingWidth = CurrentFrame.Width;
            boundingHeight = CurrentFrame.Height;
        }

        public virtual void Update(float deltaT)
        {
            if (frameDuration != 0f)
            {
                elapsedTime += deltaT;

                if (elapsedTime >= frameDuration)
                {
                    currentFrameIndex = (currentFrameIndex + 1) % animationMap[currentAnimation].Length;
                    elapsedTime = 0f;
                }
            }
        }

        public virtual void Draw(SpriteBatch spriteBatch)
        {
            if (DrawingBounds)
                spriteBatch.Draw(Storage.boundingBox, Bounds, Color.LimeGreen);
            if (!flip)
                spriteBatch.Draw(CurrentFrame, position, color);
            else
            {
                spriteBatch.Draw(CurrentFrame, position, null, color, 0f, default(Vector2), 1f, SpriteEffects.FlipHorizontally, 0f);
                
            }
        }

        public virtual void SwitchAnimation(string animation)
        {
            if (!currentAnimation.Contains(animation))
            {
                currentAnimation = animation;
                currentFrameIndex = 0;
            }
        }
    }
}
