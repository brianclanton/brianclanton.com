﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SNFEGame.Util;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.Timers;

namespace SNFEGame.Visual
{
    class DisappearingBlock:Block
    {
        public Boolean pop;
        private Boolean remove;
        Character player;
        Timer timer;
        List<Sprite> list;
        private String type;

        public DisappearingBlock(Vector2 position, String type, Character player)
            : base(position, type)
        {
            pop = false;
            this.player = player;
            timer = new Timer(0800);
            this.type = type;
        }


        public override void Update(float deltaT)
        {
            /*Rectangle newBounds = new Rectangle(Bounds.X-50, Bounds.Y-50, Bounds.Width+50, Bounds.Height+50);

            if (Bounds.Intersects(player.Bounds))
                pop = true;
            if (pop)
            {
                timer.Elapsed += new ElapsedEventHandler(timer_Elapsed);
	            timer.Enabled = true;
            }*/
            if (remove)
            {

                list.Remove(this);
                timer.Enabled = false;

            }
            
            base.Update(deltaT);
        }

        private void timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            remove = true;
            list.Remove(this);
            timer.Enabled = false;
        }

        public void beginCountDown(List<Sprite> list)
        {
            CurrentFrame = Storage.GetBlockTexture(type/* + " (Cracked)"*/);
            pop = true;
            this.list = list;
            timer.Elapsed += new ElapsedEventHandler(timer_Elapsed);
            timer.Enabled = true;
        }

    }
}
