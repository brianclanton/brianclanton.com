﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace SNFEGame.Visual
{
    class MovingBlock : Block
    {
        protected Vector2 startingPosition;
        public Vector2 velocity;
        protected int range;
        private MainGame game;

        public MovingBlock(Vector2 position, string type, Vector2 velocity, int range, MainGame game)
            : base(position, type)
        {
            this.velocity = velocity;
            this.range = range;
            startingPosition = position;
            this.game = game;
        }

        public override void Update(float deltaT)
        {
            if (velocity.X != 0) {
                if (position.X >= startingPosition.X + range / 2 ||
                    position.X <= startingPosition.X - range / 2)
                {
                    velocity.X *= -1;
                    //if (Bounds.Intersects(game.player.Bounds))
                    //{
                     
                      //    game.player.position.X += velocity.X * deltaT * 1.2f;
                       
                    //}
                      //if (Bounds.Intersects(player.Bounds))
                      //  player.position.X += velocity.X * -1 * deltaT;
                
                }


                float projectedX = Bounds.X + velocity.X * deltaT;
                Rectangle checkX = new Rectangle((int)projectedX, (int)Bounds.Y + 2, Bounds.Width, Bounds.Height);
               
                    //if (!game.player.Bounds.Intersects(checkX))
                    //{
                    //    position.X += velocity.X * deltaT;
                    //}





                
            } else if (velocity.Y != 0) {
                if (position.Y >= startingPosition.Y + range / 2 ||
                    position.Y <= startingPosition.Y - range / 2)
                    velocity.Y *= -1;

                position.Y += velocity.Y * deltaT;
            }
            base.Update(deltaT);
        }
    }
}
