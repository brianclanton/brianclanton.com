﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SNFEGame.Util;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using XmlDependent;

namespace SNFEGame.Visual
{
    class LinkedBlock:Block
    {
        private Block target;


        public LinkedBlock(BlockSpriteData b)
            : base(b)
        { }

        public LinkedBlock(BlockSpriteData b, Block target)
            : base(b)
        {
            this.target = target;

        }

        public Block partner
        {
            get
            {
                if (this.target != null)
                    return this.target;
                else
                    return this;
            }

            set
            {
                this.target = value;

            }


        }


    }
}
