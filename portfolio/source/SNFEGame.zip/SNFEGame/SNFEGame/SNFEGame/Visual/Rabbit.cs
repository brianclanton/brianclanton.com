﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SNFEGame.Util;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace SNFEGame.Visual
{
    class Rabbit:Environment
    {
        const float xVelocity = 500f;
        public static Random rand = new Random();
        public static float finishLine;
        public MainGame game;

        public Rabbit(MainGame game) : base(Storage.GetBlockTexture("SparkBlue"))
        {
            position = new Vector2(300f, 420f);
            //finishLine = game.drawSprites[game.drawSprites.Count - 1].position.X;
            this.game = game;
        }

        public Color generateRandomColor()
        {
            ///These are the values of the random colors that fit with the theme, along with some darker colors
            int r = rand.Next(0, 256);
            int g = rand.Next(0, 256);
            int b = rand.Next(0, 256);
            //int a = rand.Next(0, 156) + 100;
            return new Color(r, g, b);
        }

        public override void Update(float deltaT)
        {
            position.X += xVelocity * deltaT;
            //if (position.X >= finishLine)
            //    game.rabbitWin = true;

        }

        public override void Draw(Microsoft.Xna.Framework.Graphics.SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(CurrentFrame, position, generateRandomColor());
        }


    }
}
