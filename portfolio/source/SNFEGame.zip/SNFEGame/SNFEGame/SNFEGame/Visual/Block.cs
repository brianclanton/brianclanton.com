﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SNFEGame.Util;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using XmlDependent;

namespace SNFEGame.Visual
{
    /// <summary>
    /// A specific type of platforming element, a basic, rectangular object to jump on and over
    /// </summary>
    public class Block : Environment
    {
        public Block(BlockData b, Vector2 bounds):base(Storage.GetBlockTexture("Small Block"))
        {
            Vector2 coordinates = new Vector2((float)b.x,(float)b.y);
            base.position = coordinates;

            if (bounds != Vector2.Zero)
            {
                boundingWidth = (int) bounds.X;
                boundingHeight = (int) bounds.Y;
            }
        }

        public Block(BlockSpriteData b):base(b.type.Equals("Linked Block") ? Storage.GetBlockTexture("mediumBlock") : Storage.GetBlockTexture(b.type))
        {
            Vector2 coordinates = new Vector2(float.Parse(b.xPosition), float.Parse(b.yPosition));
            base.position = coordinates;
            boundingHeight = CurrentFrame.Bounds.Height;
            boundingWidth = CurrentFrame.Bounds.Width;
          
        }

        public Block(Vector2 position)
            : base(Storage.GetBlockTexture("Small Block"))
        {
            base.position = position;
            
        }

        public Block(Vector2 position, String type) : base(Storage.GetBlockTexture(type))
        {
            base.position = position;
            
        }

        public override void Update(float deltaT)
        {

        }

        public override void Draw(Microsoft.Xna.Framework.Graphics.SpriteBatch spriteBatch)
        {
            base.Draw(spriteBatch);
        }
    }
}
