﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SNFEGame.Util;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace SNFEGame.Visual
{
    class BackgroundFlier : Environment
    {

        /// <summary>
        /// Edit me to change the speed of the background bits
        /// </summary>
        const float xVelocity = -1000f;
        static Random rand = new Random();
        public int counter = 0;
        public float playerXPosition;

        public BackgroundFlier(float playerXPosition):base(Storage.GetBlockTexture("Dot"))
        {
            this.playerXPosition = playerXPosition;
            generateRandomStart();

        }

        public void generateRandomStart()
        {
            ///These values spawn the background bits in random spots throughout the level
            //int x = rand.Next(0, 40000)-5000; 
            int y = rand.Next(0, 1000);
            float x = playerXPosition+1200;
            position = new Vector2(x, (float)y);
        }

        public Color generateRandomColor()
        {
            ///These are the values of the random colors that fit with the theme, along with some darker colors
            int r = rand.Next(64, 80);
            int g = rand.Next(96, 128);
            int b = rand.Next(80, 128);
            //int a = rand.Next(0, 156) + 100;
            return new Color(r, g, b, 50);
        }

        public override void Update(float deltaT)
        {
            position.X += xVelocity * deltaT;
            counter++;
        }

        public override void Draw(Microsoft.Xna.Framework.Graphics.SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(CurrentFrame, position, generateRandomColor());
        }
    }
}
