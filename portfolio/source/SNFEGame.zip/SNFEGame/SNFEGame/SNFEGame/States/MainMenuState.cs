﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using SNFEGame.Menus;
using SNFEGame.Util;


namespace SNFEGame.States
{
    public class MainMenuState : BaseState
    {

        private Menu mainMenu;

        public MainMenuState()
        {
            Initialize();
        }

        protected override void Initialize()
        {
            MediaPlayer.Stop();
            List<MenuItem> items = new List<MenuItem>();
            items.Add(new MenuItem("Start Game", delegate()
            {
                MainGame.GoToGame(); 
            }));
            items.Add(new MenuItem("Exit", delegate()
            {
                MainGame.CloseApplication();
            }));

            mainMenu = new Menu(items, Storage.GetFont("Large"));
            mainMenu.Show();
        }

        public override void Update(float dT)
        {
            mainMenu.Update(dT);
        }

        public override void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Begin();
            spriteBatch.Draw(Storage.titleArt, Vector2.Zero, Color.White);
            spriteBatch.End();

            mainMenu.Draw(spriteBatch);
        }
    }
}
