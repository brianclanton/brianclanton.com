﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SNFEGame.Menus
{
    public class MenuItem
    {
        public delegate void MenuItemDelegate();

        private string text;

        public string Text
        {
            get { return text; }
            set { text = value; }
        }

        private MenuItemDelegate method;

        public MenuItem(string text)
        {
            this.text = text;
        }

        public MenuItem(string text, MenuItemDelegate method) : this(text)
        {
            this.method = method;
        }

        public void CallMethod()
        {
            if (method != null)
                method();
        }
    }
}
