﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace XmlDependent
{
    public class BlockSpriteData
    {
        public string type;
        public string xPosition, yPosition;

    }
}
