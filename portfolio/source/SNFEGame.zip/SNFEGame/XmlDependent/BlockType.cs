﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SNFEGame
{
    public class BlockType
    {
        public string type;
        public int boundingWidth, boundingHeight;
    }
}