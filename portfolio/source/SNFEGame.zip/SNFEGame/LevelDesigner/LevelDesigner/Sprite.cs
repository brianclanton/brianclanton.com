﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using XmlDependent;

namespace LevelDesigner
{
    public class Sprite
    {
        public Vector2 position;
        public string type;
        public Texture2D image;
        //public Texture2D image2;
        public Rectangle size;
         
        public Sprite(string type, float xPosition, float yPosition)
        {
            this.type = type;
            position = new Vector2(xPosition, yPosition);
            if (type.Equals("smallBlock"))
            {
                image = Storage.SmallBlock;
                //image2 = null;
            }
            else if (type.Equals("mediumBlock"))
            {
                image = Storage.MediumBlock;
                //image2 = null;
            }
            else if (type.Equals("largeBlock"))
            {
                image = Storage.LargeBlock;
                //image2 = null;
            }
            else if (type.Equals("Start Flag"))
            {
                image = Storage.StartFlag;
                //image2 = null;
            }
            else if (type.Equals("End Flag"))
            {
                image = Storage.EndFlag;
                //image2 = null;
            }
            else if (type.Equals("brick11"))
            {
                image = Storage.Brick11;
                //image2 = Storage.Brick12;
            }
            else if (type.Equals("brick21"))
            {
                image = Storage.Brick21;
                //image2 = Storage.Brick22;
            }
            else if (type.Equals("brick31"))
            {
                image = Storage.Brick31;
                //image2 = Storage.Brick32;
            }
            else if (type.Equals("brick41"))
            {
                image = Storage.Brick41;
                //image2 = Storage.Brick42;
            }

            size = image.Bounds;
        }

        public Sprite(BlockSpriteData b) : this(b.type, float.Parse(b.xPosition), float.Parse(b.yPosition)) { }

        public virtual void draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(image, position, null, Color.White, 0f, default(Vector2), 1f, SpriteEffects.FlipHorizontally, 0f);
        }

        public BlockSpriteData ToBlockSpriteData()
        {
            BlockSpriteData bsd = new BlockSpriteData();
            bsd.type = type;
            bsd.xPosition = "" + position.X;
            bsd.yPosition = "" + position.Y;

            return bsd;
        }


    }
}
