﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LevelDesigner
{
    public partial class LoadWindow : Form
    {
        public Game1 game;

        public LoadWindow(Game1 game)
        {
            InitializeComponent();
            this.game = game;
            this.game.savingOrLoading = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            game.savingOrLoading = false;
            this.Close();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                game.savingOrLoading = false;
                game.Load(textBox1.Text);
                this.Close();
            }
        }
    }
}
