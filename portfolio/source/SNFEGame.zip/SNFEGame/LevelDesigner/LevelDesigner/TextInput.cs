﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace LevelDesigner
{
    public class TextInput
    {
        private Keys[] keysToCheck = new Keys[] {
            Keys.A, Keys.B, Keys.C, Keys.D, Keys.E,
            Keys.F, Keys.G, Keys.H, Keys.I, Keys.J,
            Keys.K, Keys.L, Keys.M, Keys.N, Keys.O,
            Keys.P, Keys.Q, Keys.R, Keys.S, Keys.T,
            Keys.U, Keys.V, Keys.W, Keys.X, Keys.Y,
            Keys.Z };
        private bool[] keysPressed;

        private const float CURSOR_BLINK_TIME = .5f;
        private const float ERROR_WAIT_TIME = .2f;

        private string title;
        private string text;

        private float currentCursorTime = 0f;
        private bool drawingCursor = true;

        private float currentErrorTime = 0f;
        private bool pastErrorZone = false;

        private bool backPressed = false;

        private bool active = false;
        private bool inputDone = false;

        public string Text
        {
            get { return text; }
        }

        public bool Active
        {
            get { return active; }
        }

        public bool InputDone
        {
            get { return inputDone; }
        }

        public TextInput(string title)
        {
            this.title = title;
            text = "";
            keysPressed = new bool[keysToCheck.Length];

            for (int i = 0; i < keysPressed.Length; i++)
                keysPressed[i] = false;
        }

        public void Update(float dT)
        {
            if (!inputDone)
            {
                #region Key Input Carry Over Error Prevention
                if (!pastErrorZone)
                {
                    currentErrorTime += dT;

                    if (currentErrorTime >= ERROR_WAIT_TIME)
                        pastErrorZone = true;
                }
                #endregion

                #region Cursor Implementation
                currentCursorTime += dT;

                if (currentCursorTime >= CURSOR_BLINK_TIME)
                {
                    drawingCursor = !drawingCursor;
                    currentCursorTime = 0f;
                }
                #endregion

                #region Key Input
                if (pastErrorZone)
                {
                    for (int i = 0; i < keysToCheck.Length; i++)
                    {
                        if (!keysPressed[i] && Keyboard.GetState(PlayerIndex.One).IsKeyDown(keysToCheck[i]))
                        {
                            keysPressed[i] = true;
                            bool shift = Keyboard.GetState(PlayerIndex.One).IsKeyDown(Keys.LeftShift) || Keyboard.GetState(PlayerIndex.One).IsKeyDown(Keys.RightShift);
                            text += shift ? keysToCheck[i].ToString() : keysToCheck[i].ToString().ToLower();
                        }
                        else if (keysPressed[i] && Keyboard.GetState(PlayerIndex.One).IsKeyUp(keysToCheck[i]))
                        {
                            keysPressed[i] = false;
                        }
                    }

                    if (!backPressed && Keyboard.GetState(PlayerIndex.One).IsKeyDown(Keys.Back) && text.Length != 0)
                    {
                        backPressed = true;
                        text = text.Remove(text.Length - 1);
                    }
                    else if (backPressed && Keyboard.GetState(PlayerIndex.One).IsKeyUp(Keys.Back))
                    {
                        backPressed = false;
                    }
                    else if (Keyboard.GetState(PlayerIndex.One).IsKeyDown(Keys.Enter))
                    {
                        inputDone = true;
                        active = false;
                    }
                }
                #endregion
            }
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            Vector2 size = Storage.TextInputFont.MeasureString(title + ": " + text);

            spriteBatch.Begin();
            spriteBatch.Draw(Storage.WhiteDot, new Rectangle(0, 0, Game1.Width, Game1.Height), Color.Black * .5f);
            spriteBatch.DrawString(Storage.TextInputFont, title + ": " + text + (drawingCursor ? "|" : ""),
                new Vector2((Game1.Width - size.X) / 2, (Game1.Height - size.Y) / 2), Color.White);
            spriteBatch.End();
        }

        public void Show()
        {
            active = true;
        }

        public void Hide()
        {
            active = false;
            text = "";
            currentCursorTime = 0f;
            currentErrorTime = 0f;
            drawingCursor = false;
            pastErrorZone = false;

            for (int i = 0; i < keysPressed.Length; i++)
                keysPressed[i] = false;
            backPressed = false;
            inputDone = false;
        }
    }
}
