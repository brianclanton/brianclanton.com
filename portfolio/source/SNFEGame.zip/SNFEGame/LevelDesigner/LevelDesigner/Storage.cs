﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.IO;

namespace LevelDesigner
{
    public class Storage
    {
        private static SpriteFont font;
        private static SpriteFont textInputFont;
        private static Texture2D smallBlock;
        private static Texture2D mediumBlock;
        private static Texture2D largeBlock;
        private static Texture2D startFlag;
        private static Texture2D endFlag;
        private static Texture2D horzGridLine;
        private static Texture2D vertGridLine;
        private static Texture2D whiteDot;
        private static Texture2D brick11;
        private static Texture2D brick12;
        private static Texture2D brick21;
        private static Texture2D brick22;
        private static Texture2D brick31;
        private static Texture2D brick32;
        private static Texture2D brick41;
        private static Texture2D brick42;
        private static Texture2D skyYellow;
        public static Texture2D SkyYellow
        {
            get { return skyYellow; }
        }
        public static Texture2D Brick11
        {
            get { return brick11; }
        }
        public static Texture2D Brick12
        {
            get { return brick12; }
        }
        public static Texture2D Brick21
        {
            get { return brick21; }
        }
        public static Texture2D Brick22
        {
            get { return brick22; }
        }
        public static Texture2D Brick31
        {
            get { return brick31; }
        }
        public static Texture2D Brick32
        {
            get { return brick32; }
        }
        public static Texture2D Brick41
        {
            get { return brick41; }
        }
        public static Texture2D Brick42
        {
            get { return brick42; }
        }


        public static Texture2D SmallBlock
        {
            get { return smallBlock; }
        }
        public static Texture2D MediumBlock
        {
            get { return mediumBlock;}
        }
        public static Texture2D LargeBlock
        {
            get { return largeBlock; }
        }
        public static SpriteFont Font
        {
            get { return font; }
        }
        public static SpriteFont TextInputFont
        {
            get { return textInputFont; }
        }
        public static Texture2D StartFlag
        {
            get { return startFlag; }
        }
        public static Texture2D EndFlag
        {
            get { return endFlag; }
        }
        public static Texture2D HorzGridLine
        {
            get { return horzGridLine; }
        }
        public static Texture2D VertGridLine
        {
            get { return vertGridLine; }
        }
        public static Texture2D WhiteDot 
        {
            get { return whiteDot; }
        }

        public static void initialize(ContentManager content)
        {
            smallBlock = content.Load<Texture2D>("Blocks\\smallBlock");
            mediumBlock = content.Load<Texture2D>("Blocks\\mediumBlock");
            largeBlock = content.Load<Texture2D>("Blocks\\largeBlock");
            startFlag = content.Load<Texture2D>("Blocks\\Start Flag");
            endFlag = content.Load<Texture2D>("Blocks\\End Flag");
            font = content.Load<SpriteFont>("Font\\font");
            textInputFont = content.Load<SpriteFont>("Font/TextInput");
            horzGridLine = content.Load<Texture2D>("Blocks\\horzGridLine");
            vertGridLine = content.Load<Texture2D>("Blocks\\vertGridLine");
            whiteDot = content.Load<Texture2D>("Blocks/WhiteBox");
            brick11 = content.Load<Texture2D>("Blocks\\brick11");
            brick12 = content.Load<Texture2D>("Blocks\\brick12");
            brick21 = content.Load<Texture2D>("Blocks\\brick21");
            brick22 = content.Load<Texture2D>("Blocks\\brick22");
            brick31 = content.Load<Texture2D>("Blocks\\brick31");
            brick32 = content.Load<Texture2D>("Blocks\\brick32");
            brick41 = content.Load<Texture2D>("Blocks\\brick41");
            brick42 = content.Load<Texture2D>("Blocks\\brick42");
            skyYellow = content.Load<Texture2D>("Blocks\\skyYellow");
        }
    }
}
