ModelQueue = function(size) {
	this.size = size !== undefined ? size : 3;
	
	var queue = [];
}

ModelQueue.prototype = {
	constructor : function() {
		
	}
}
