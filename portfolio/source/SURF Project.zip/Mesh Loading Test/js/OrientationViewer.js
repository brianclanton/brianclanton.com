OrientationViewer = function(parameters) {
	
	this.width = parameters.width !== undefined ? 
		parameters.width : 
		parameters.height !== undefined ? parameters.height : 200;
		
	this.height = parameters.height !== undefined ? 
		parameters.height : 
		parameters.width !== undefined ? parameters.width : 200;
	
	
	
	this.domElement = paramaters.container !== undefined ? parameters.container : document.createElement("div");
};

OrientationViewer.prototype.constructor = OrientationViewer;
